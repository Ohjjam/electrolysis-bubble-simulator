"""The property/context bundle — the single frozen interface between the
operating point and every physics consumer.

`build_context(op, params)` evaluates all state-dependent property correlations
and model coefficients into one flat dict. Solvers, the bubble model and the
tests all read from this dict, so its keys are an **interface contract: add
keys, never rename or remove them** (existing consumers and golden tests bind to
`j0`, `tafel_b`, `j_lim_eff`, `kappa`, `sigma`, `d_rho`, ...). New physics phases
append keys (e.g. `j0_anode`, `eta_conc` inputs) without disturbing this set.
"""
from .. import properties as prop
from . import transport, chemistry


def build_context(op, params) -> dict:
    """Assemble the property bundle used by the physics for the current state."""
    med = getattr(op, "electrolyte", "KOH")
    hf = getattr(op, "high_fidelity", False)   # Pitzer activity + Gilliam conductivity (KOH)
    d = {
        "E_rev": prop.reversible_voltage(op.T, op.P),
        "kappa": prop.conductivity(med, op.c_electrolyte, op.T, high_fidelity=hf),
        "sigma": prop.surface_tension_med(med, op.T, op.c_electrolyte),
        "rho_l": prop.liquid_density_med(med, op.c_electrolyte),
        "rho_g": prop.gas_density(op.electrode, op.T, op.P),
        "mu": prop.liquid_viscosity_med(med, op.c_electrolyte, op.T),
        "fritz_scale": params.fritz_scale,
        "j0": params.j0,
        "tafel_b": params.tafel_b,
        "j_lim_eff": params.j_lim * (1.0 + params.flow_jlim * op.u_flow),
        "Cd_flow": params.Cd_flow,
        "k_mhd": params.k_mhd,
        "r_min_detach": params.r_min_detach,
    }
    # --- two-electrode (Butler-Volmer) coefficients + series resistances ---
    # (additive keys; the lumped solver ignores them, so golden values are unchanged)
    a, c = params.anode, params.cathode
    # activity-corrected concentration order (a = gamma_pm * c), normalized to the
    # reference concentration (6.0 M = j0_arrhenius c_ref) so defaults are golden-safe.
    act = chemistry.activity_for(op.c_electrolyte, op.T, med, high_fidelity=hf)
    act_ref = chemistry.activity_for(6.0, op.T, med, high_fidelity=hf)
    d["j0_anode"] = prop.j0_arrhenius(a.j0_ref, a.Ea_j0, op.T, op.c_electrolyte,
                                      a.gamma_c, activity=act, activity_ref=act_ref)
    d["j0_cathode"] = prop.j0_arrhenius(c.j0_ref, c.Ea_j0, op.T, op.c_electrolyte,
                                        c.gamma_c, activity=act, activity_ref=act_ref)
    d["alpha_a_anode"], d["alpha_c_anode"] = a.alpha_a, a.alpha_c
    d["alpha_a_cathode"], d["alpha_c_cathode"] = c.alpha_a, c.alpha_c
    d["r_membrane_area"] = params.r_membrane_area
    d["r_contact_area"] = params.r_contact_area

    # --- mass transport: Sherwood-grounded limiting current + Henry saturation ---
    d["sh_enhancement"] = transport.flow_enhancement(op, d, params)
    d["j_lim_transport"] = params.j_lim * d["sh_enhancement"]
    d["z_primary"] = prop.GAS[op.electrode]["z"]
    d["c_sat_gas"] = transport.saturation_concentration(op.P, params.k_henry)
    d["k_vogt"] = params.k_vogt            # bubble self-stirring (applied in-solver, j-dependent)
    d["j_ref_vogt"] = params.j_ref_vogt

    # --- electrolyte chemistry (bulk; surface pH is current-dependent, set in solver) ---
    d["electrolyte"] = med
    d["ionic_strength"] = chemistry.ionic_strength(op.c_electrolyte, med)
    d["activity_coeff"] = chemistry.activity_for(op.c_electrolyte, op.T, med, high_fidelity=hf)
    d["pH_bulk"] = chemistry.bulk_pH(op.c_electrolyte, op.T, med)
    d["t_carrier"] = prop.ELECTROLYTES[med]["t_carrier"]
    # (coalescence threshold is read straight from ELECTROLYTES where needed —
    #  population.coalesce / server — so no context key for it, avoiding a dangling node)
    d["D_carrier"] = params.D_reactant
    # Nernst diffusion-layer thickness delta = L_char / Sh (flow thins it) [m]
    d["delta_bl"] = params.L_char / (params.sh0 * d["sh_enhancement"])

    # --- geometry the solvers need for void-resistance partitioning ---
    d["gap_m"] = op.gap_mm * 1e-3
    d["near_layer_m"] = params.near_layer

    d["d_rho"] = d["rho_l"] - d["rho_g"]
    return d
