"""Source terms: converting current into evolved-gas (and later, heat).

Shared by every fidelity — the Faraday + ideal-gas conversion of current to a
gas volume rate is the same whether the current came from a 0D or a 2D solver.
"""
from ..constants import F, R_GAS
from ..properties import GAS


def faradaic_gas_rate(j, electrode, T, P, area):
    """Evolved-gas volume rate [m^3/s] at cell conditions.

        I = j * area ;  n_dot = I / (z F) ;  Q = n_dot * R T / P

    `z` electrons per gas molecule (HER: H2, z=2; OER: O2, z=4) so HER evolves
    twice the gas volume of OER per unit charge.
    """
    z = GAS[electrode]["z"]
    I = j * area
    n_dot = I / (z * F)            # mol/s
    return n_dot * R_GAS * T / P   # m^3/s of gas at cell (T, P)


def faradaic_molar_rate(j, electrode, area):
    """Evolved-gas molar rate [mol/s] = j * area / (z F).

    The dissolved-gas / supersaturation model needs moles, not volume; this is
    the same Faraday law without the ideal-gas volume conversion.
    """
    z = GAS[electrode]["z"]
    return j * area / (z * F)
