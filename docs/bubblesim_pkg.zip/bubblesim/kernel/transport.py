"""Mass-transport correlations: boundary layer, limiting current, concentration
overpotential, and dissolved-gas (Henry) supersaturation.

These are 0D-usable helpers and also the constitutive layer the 1D solver will
reuse. Two notes on the physics:

  * In alkaline water electrolysis the bulk electrolyte (KOH) is not the limiting
    reactant, so the concentration overpotential is small except as the current
    approaches the transport limit. It is included for completeness and for the
    regimes (high rate, poor convection) where it matters; it also enforces the
    transport limit smoothly (eta_conc -> infinity as j -> j_lim).
  * Flow raises the limiting current through the Sherwood number
    (Sh ~ Re^1/2 Sc^1/3), which replaces the earlier ad-hoc linear bump.
"""
import math

from ..constants import F, R_GAS


def reynolds(rho, u, L, mu):
    """Reynolds number  Re = rho u L / mu  (0 at no flow)."""
    return rho * u * L / mu


def schmidt(mu, rho, D):
    """Schmidt number  Sc = mu / (rho D) = nu / D."""
    return mu / (rho * D)


def sherwood(Re, Sc, sh0=1.0, coeff=6.0e-4):
    """Sherwood number  Sh = sh0 + coeff * Re^0.5 * Sc^(1/3).

    The forced-convection term is the laminar boundary-layer scaling
    (Sh ~ Re^1/2 Sc^1/3); `sh0` is the no-flow (diffusion / natural-convection)
    floor so Sh stays finite at u = 0.
    """
    return sh0 + coeff * Re ** 0.5 * Sc ** (1.0 / 3.0)


def mass_transfer_coeff(Sh, D, L):
    """Mass-transfer coefficient  k_m = Sh D / L  [m/s]."""
    return Sh * D / L


def flow_enhancement(op, props, params):
    """Limiting-current enhancement  Sh(Re)/sh0 = 1 + (coeff/sh0) Re^0.5 Sc^(1/3).

    Grounds the flow dependence of j_lim in the Sherwood correlation; equals 1 at
    no flow, rising ~u^1/2 with cross-flow.
    """
    rho, mu, D, L = props["rho_l"], props["mu"], params.D_reactant, params.L_char
    Re = reynolds(rho, op.u_flow, L, mu)
    Sc = schmidt(mu, rho, D)
    return sherwood(Re, Sc, params.sh0, params.sh_coeff) / params.sh0


def vogt_enhancement(j, j_ref, k_vogt):
    """Bubble self-stirring (Vogt) limiting-current enhancement [-]:

        f = 1 + k_vogt * sqrt(max(j,0) / j_ref)

    Detaching/rising bubbles agitate the boundary layer at gas-evolving
    electrodes — often the *dominant* mass-transport mechanism. Because it
    depends on the current being solved, the solvers apply it inside their
    implicit loop (consistently in CA and CP, preserving CA<->CP symmetry).
    k_vogt=0 disables it (returns 1).
    """
    if k_vogt <= 0.0 or j_ref <= 0.0:
        return 1.0
    return 1.0 + k_vogt * math.sqrt(max(j, 0.0) / j_ref)


def vogt_limit(j_lim_base, j_ref, k_vogt):
    """Self-consistent Vogt-enhanced transport limit: the EXACT fixed point of

        j = j_lim_base * (1 + k_vogt * sqrt(j / j_ref)).

    Substituting s = sqrt(j) gives a quadratic
        s^2 - (j_lim_base * k_vogt / sqrt(j_ref)) * s - j_lim_base = 0,
    solved in closed form (no iteration / under-convergence) so the CP clamp and
    the CA bracket sit exactly on the ceiling and the two modes agree on it.
    Returns j_lim_base when self-stirring is disabled.
    """
    if k_vogt <= 0.0 or j_ref <= 0.0:
        return j_lim_base
    b = j_lim_base * k_vogt / math.sqrt(j_ref)
    s = 0.5 * (b + math.sqrt(b * b + 4.0 * j_lim_base))
    return s * s


def conc_overpotential(j, j_lim, z, T):
    """Concentration (mass-transport) overpotential [V]:

        eta_conc = -(RT / zF) ln(1 - j / j_lim),   0 <= j < j_lim.

    Diverges as j -> j_lim, which enforces the transport limit in the voltage
    balance. The argument is clamped just below 1 for numerical safety.
    """
    if j <= 0.0:
        return 0.0
    x = j / j_lim
    if x >= 1.0 - 1e-9:
        x = 1.0 - 1e-9
    return -(R_GAS * T) / (z * F) * math.log(1.0 - x)


def surface_conc_ratio(j, j_lim):
    """Surface/bulk reactant concentration ratio  c_s/c_b = 1 - j/j_lim
    (the input to the local-pH model). Clamped to (0, 1]."""
    return max(1e-9, 1.0 - j / j_lim)


def saturation_concentration(P_gas, k_henry):
    """Henry's-law dissolved-gas saturation concentration  c_sat = P_gas / k_H
    [mol/m^3]  (k_H in [Pa*m^3/mol])."""
    return P_gas / k_henry


def supersaturation(c_dissolved, c_sat):
    """Supersaturation ratio  S = c_dissolved / c_sat  (S > 1 drives nucleation)."""
    return c_dissolved / c_sat if c_sat > 0.0 else 0.0
