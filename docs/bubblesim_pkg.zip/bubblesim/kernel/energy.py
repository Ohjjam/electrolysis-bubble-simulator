"""Energy balance: reaction + ohmic heat vs cooling, making the cell temperature
a dynamic state instead of a fixed input.

Total heat dissipated is I (V_cell - V_tn), where V_tn = dH / (zF) ~ 1.48 V is
the thermoneutral voltage: at V_cell = V_tn the cell is (adiabatically) heat
balanced; above it the surplus electrical power becomes heat. Because V_cell
already carries the ohmic (j^2 R) and activation losses, this single expression
captures all irreversible heating plus the reversible (entropic) term.

The lumped balance  C dT/dt = Q_gen - Q_cool  closes the loop: current heats the
cell, raising T, which lowers E_rev and raises conductivity (a positive feedback
bounded by cooling). Defaults are calibration knobs; a real cell's thermal mass
makes T evolve over minutes, far slower than the bubble dynamics.
"""
V_THERMONEUTRAL = 1.481   # thermoneutral cell voltage for water splitting [V]


def heat_flux(j, V_cell, V_tn=V_THERMONEUTRAL):
    """Areal heat generation rate [W/m^2] = j (V_cell - V_tn), clamped at 0
    (this lumped model does not draw heat in below the thermoneutral voltage)."""
    return max(0.0, j * (V_cell - V_tn))


def cooling_rate(T, T_amb, hA):
    """Newtonian heat removal [W] = hA (T - T_amb)  (hA = coeff * area [W/K])."""
    return hA * (T - T_amb)


def temperature_step(T, Q_gen, Q_cool, C, dt):
    """Explicit-Euler update of the lumped energy balance  C dT/dt = Q_gen - Q_cool."""
    return T + (Q_gen - Q_cool) / C * dt


def steady_temperature(Q_gen, T_amb, hA):
    """Steady-state temperature where Q_gen balances cooling: T = T_amb + Q_gen/hA."""
    return T_amb + Q_gen / hA if hA > 0 else float("inf")
